# Lab 3
By: Cole Hoener  
Class: CS-283 Section 3  
Date: 24 Feburary 2021

## Description
To create two C program that follows the constraints as outlined in the Lab3 instructions.  
(See client.c header and server.c header for more info)

## Requirements
- C Compiler

## Usage

For client
```bash
make client
./client.o host port file
```

For server
```bash
make server
./server.o port
```

## Testing
I tested my code by trying all edge cases and obvious cases.

## Experience
This assignment was very long but was honestly kind of fun. A good challenge never hurts.

## Suggestions
Found this lab to have more useful info from the slides for help and the given network files were also handy